-- Función para obtener la lista de procesos y pestañas abiertos
local function obtenerListaProcesos()
  local listaProcesos = {}
  local listaPestanas = {}

  for _, computer in ipairs(peripheral.getNames()) do
    if peripheral.getType(computer) == "computer" then
      local id = peripheral.call(computer, "getID")
      local procesos = peripheral.call(computer, "list")
      listaProcesos[id] = procesos
      local pestañas = peripheral.call(computer, "listTabs")
      listaPestanas[id] = pestañas
    end
  end

  return listaProcesos, listaPestanas
end

-- Función para guardar la lista de procesos y pestañas en un archivo
local function guardarLista(listaProcesos, listaPestanas, archivo)
  local file = fs.open(archivo, "w")
  file.write("=== Procesos ===\n")
  for id, procesos in pairs(listaProcesos) do
    file.write("Computer ID: " .. id .. "\n")
    for _, proceso in ipairs(procesos) do
      file.write("- " .. proceso .. "\n")
    end
    file.write("\n")
  end

  file.write("\n=== Pestañas ===\n")
  for id, pestañas in pairs(listaPestanas) do
    file.write("Computer ID: " .. id .. "\n")
    for _, pestaña in ipairs(pestañas) do
      file.write("- " .. pestaña .. "\n")
    end
    file.write("\n")
  end

  file.close()
end

-- Función para cerrar todos los procesos y pestañas excepto el especificado
local function cerrarProcesosPestanasEspecificados(listaProcesos, listaPestanas, procesoEspecificado)
  for id, procesos in pairs(listaProcesos) do
    for _, proceso in ipairs(procesos) do
      if proceso ~= procesoEspecificado then
        peripheral.call("computer", "terminate", id, proceso)
      end
    end
  end

  for id, pestañas in pairs(listaPestanas) do
    for _, pestaña in ipairs(pestañas) do
      if pestaña ~= procesoEspecificado then
        peripheral.call("computer", "closeTab", id, pestaña)
      end
    end
  end
end

-- Obtener la lista de procesos y pestañas abiertos
local listaProcesos, listaPestanas = obtenerListaProcesos()

-- Guardar la lista en el archivo especificado
local archivo = "/RAM/Taskiller.txt"
if not fs.exists(archivo) then
  fs.open(archivo, "w").close()
end
guardarLista(listaProcesos, listaPestanas, archivo)

-- Cerrar todos los procesos y pestañas excepto el especificado
local procesoEspecificado = "BurlaCMD" -- Reemplaza "BurlaCMD" con el nombre del proceso que deseas mantener abierto
cerrarProcesosPestanasEspecificados(listaProcesos, listaPestanas, procesoEspecificado)

-- Cerrar el programa
os.queueEvent("terminate")
