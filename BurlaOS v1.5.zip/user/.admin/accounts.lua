local function clearScreen()
  term.setBackgroundColor(colors.black)
  term.clear()
  term.setCursorPos(1, 1)
end

local function centerText(y, text)
  local width, _ = term.getSize()
  local x = math.floor(width / 2 - #text / 2)
  term.setCursorPos(x, y)
  print(text)
end

local function centerTextInput(y, prompt)
  local width, _ = term.getSize()
  local x = math.floor(width / 2 - #prompt / 2)
  term.setCursorPos(x, y)
  return read()
end

local function createAdminAccount()
  clearScreen()
  term.setBackgroundColor(colors.black)
  term.setTextColor(colors.white)

  centerText(4, "Crear cuenta de administrador")

  centerText(7, "Nombre de usuario:")
  local adminUsername = centerTextInput(9, "")

  -- Guardar el nombre de usuario del administrador en el archivo admin.txt
  local adminPath = "/user/.admin/admin.txt"
  local file = fs.open(adminPath, "w")
  if file then
    file.writeLine(adminUsername)
    file.close()
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    centerText(4, "Cuenta de administrador creada:")
    centerText(6, "Nombre de usuario: " .. adminUsername)
    sleep(2)
  else
    error("No se pudo crear el archivo de información del administrador.")
  end
end

local function validateAdminAccount()
  local adminPath = "/user/.admin/admin.txt"
  if fs.exists(adminPath) then
    local file = fs.open(adminPath, "r")
    if file then
      local adminUsername = file.readLine()
      file.close()
      return adminUsername
    end
  end
  return nil
end

local function showAccountCreationForm()
  clearScreen()
  term.setBackgroundColor(colors.black)
  term.setTextColor(colors.white)

  centerText(4, "Crear cuenta de usuario")

  centerText(7, "Nombre de usuario:")
  local username = centerTextInput(9, "")

  centerText(11, "Contraseña:")
  local password = centerTextInput(13, "*")

  -- Crear carpeta de usuario
  local userFolderPath = "/user/" .. username
  fs.makeDir(userFolderPath)

  -- Guardar la cuenta de usuario en un archivo
  local userFilePath = "/user/.admin/" .. username .. ".txt"
  local file = fs.open(userFilePath, "w")
  if file then
    file.writeLine(username)
    file.writeLine(password)
    file.close()
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    centerText(4, "Cuenta de usuario creada:")
    centerText(6, "Nombre de usuario: " .. username)
    sleep(2)
  else
    error("No se pudo crear el archivo de información del usuario.")
  end
end

local function showAccountDeletionForm()
  clearScreen()
  term.setBackgroundColor(colors.black)
  term.setTextColor(colors.white)

  centerText(4, "Eliminar cuenta de usuario")

  centerText(7, "Nombre de usuario:")
  local username = centerTextInput(9, "")

  -- Eliminar carpeta de usuario
  local userFolderPath = "/user/" .. username
  fs.delete(userFolderPath)

  -- Eliminar archivo de cuenta de usuario
  local userFilePath = "/user/.admin/" .. username .. ".txt"
  fs.delete(userFilePath)

  clearScreen()
  term.setBackgroundColor(colors.black)
  term.setTextColor(colors.white)
  centerText(4, "Cuenta de usuario eliminada:")
  centerText(6, "Nombre de usuario: " .. username)
  sleep(2)
end

local function showChangePasswordForm()
  clearScreen()
  term.setBackgroundColor(colors.black)
  term.setTextColor(colors.white)

  centerText(4, "Cambiar contraseña")

  centerText(7, "Nombre de usuario:")
  local username = centerTextInput(9, "")

  -- Verificar si el usuario existe
  local userFilePath = "/user/.admin/" .. username .. ".txt"
  if not fs.exists(userFilePath) then
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    centerText(4, "El usuario no existe")
    sleep(2)
    return
  end

  -- Leer la contraseña actual del archivo
  local file = fs.open(userFilePath, "r")
  local storedUsername = file.readLine()
  local storedPassword = file.readLine()
  file.close()

  -- Solicitar la nueva contraseña
  centerText(11, "Nueva contraseña:")
  local newPassword = centerTextInput(13, "*")

  -- Guardar la nueva contraseña en el archivo
  file = fs.open(userFilePath, "w")
  if file then
    file.writeLine(storedUsername)
    file.writeLine(newPassword)
    file.close()
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    centerText(4, "Contraseña cambiada exitosamente")
    sleep(2)
  else
    error("No se pudo guardar la nueva contraseña.")
  end
end

local function showAccountManagementMenu()
  while true do
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)

    centerText(4, "Gestión de cuentas de usuario")
    centerText(7, "1. Crear cuenta de usuario")
    centerText(9, "2. Eliminar cuenta de usuario")
    centerText(11, "3. Cambiar contraseña")
    centerText(13, "4. Salir")
    centerText(16, "Ingrese su elección:")

    local choice = tonumber(centerTextInput(18, ""))

    if choice == 1 then
      showAccountCreationForm()
    elseif choice == 2 then
      showAccountDeletionForm()
    elseif choice == 3 then
      showChangePasswordForm()
    elseif choice == 4 then
      return
    else
      clearScreen()
      term.setBackgroundColor(colors.black)
      term.setTextColor(colors.white)

      centerText(4, "Opción inválida. Inténtelo de nuevo")
      sleep(2)
    end
  end
end

local function handleKeyPress(event)
  if event[1] == "key" and event[2] == keys.leftCtrl then
    shell.run("shutdown")
    os.queueEvent("terminate")
  end
end

local function main()
  local adminUsername = validateAdminAccount()

  if not adminUsername then
    createAdminAccount()
    return
  end

  while true do
    clearScreen()
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)

    centerText(4, "Gestión de cuentas de usuario")
    centerText(7, "1. Administrar cuentas de usuario")
    centerText(9, "2. Salir")
    centerText(12, "Ingrese su elección:")

    local choice = tonumber(centerTextInput(14, ""))

    if choice == 1 then
      showAccountManagementMenu()
    elseif choice == 2 then
      shell.run("/user/BurlaOS/Loggin.lua")
      return
    else
      clearScreen()
      term.setBackgroundColor(colors.black)
      term.setTextColor(colors.white)

      centerText(4, "Opción inválida. Inténtelo de nuevo")
      sleep(2)
    end
  end
end

-- Programa principal
clearScreen()
term.setTextColor(colors.white)
term.setBackgroundColor(colors.black)

-- Manejar la pulsación de teclas
parallel.waitForAny(main, function()
  while true do
    local event = {os.pullEvent()}
    handleKeyPress(event)
  end
end)
