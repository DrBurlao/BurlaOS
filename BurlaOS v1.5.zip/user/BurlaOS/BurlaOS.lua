local monitor = nil
local term = nil

-- Buscar un monitor conectado
for _, p in ipairs(peripheral.getNames()) do
  if peripheral.getType(p) == "monitor" then
    monitor = peripheral.wrap(p)
    if monitor.isColor() then
      break
    else
      monitor = nil
    end
  end
end

-- Buscar un módem conectado
local modem = peripheral.find("modem")

if modem and not monitor then
  -- Buscar un monitor a través del módem
  modem.transmit(1, 1, "monitor_detect")
  local timer = os.startTimer(5)
  while true do
    local event, side, channel, reply, message = os.pullEvent()
    if event == "modem_message" and channel == 1 and message == "monitor_attached" then
      monitor = peripheral.wrap(side)
      if monitor.isColor() then
        break
      else
        monitor = nil
      end
    elseif event == "timer" and side == timer then
      break
    end
  end
end

-- Si se encuentra un monitor, úsalo como terminal
if monitor then
  term = monitor
else
  term = peripheral.find("terminal")
end

if not term then
  error("No se detectó ningún monitor o módem con cable.")
end

local categories = {
  {name = "Programas", path = "/user/BurlaOS/types/Programs.lua"},
  {name = "Explorador de archivos", path = "/user/BurlaOS/types/FileExplorer.lua"},
  {name = "Aplicaciones de usuario instaladas", path = "/user/BurlaOS/types/UserApps.lua"},
  {name = "Panel de control", path = "/user/BurlaOS/types/ControlPanel.lua"},
  {name = "Multimedia", path = "/user/BurlaOS/types/Multimedia.lua"},
  {name = "Apagado", path = "/user/BurlaOS/types/Shutdown.lua"}
}

local currentCategory = 1

local function clearScreen()
  term.setTextColor(colors.white)
  term.setBackgroundColor(colors.black)
  term.clear()
  term.setCursorPos(1, 1)
end

local function drawLauncher()
  clearScreen()

  local width, height = term.getSize()

  term.setTextColor(colors.yellow)
  term.setCursorPos((width - 13) / 2, 1)
  term.write("=== Launcher ===")

  local startY = math.floor((height - #categories) / 2) - 1

  for i, category in ipairs(categories) do
    term.setTextColor(colors.white)
    term.setCursorPos((width - #category.name) / 2, startY + i * 2)

    if i == currentCategory then
      term.setTextColor(colors.green)
      term.write("> ")
    else
      term.write("  ")
    end

    term.write(category.name)
  end
end

local function createDirectory(directory)
  if not fs.exists(directory) then
    fs.makeDir(directory)
  end
end

local function createDirectories()
  for _, category in ipairs(categories) do
    createDirectory(category.path)
  end
end

local function executeProgram(path)
  shell.run(path .. " &")
end

local function openCategory()
  local category = categories[currentCategory]
  local path = category.path

  executeProgram(path)
end

local function handleInput()
  while true do
    local event, key = os.pullEvent("key")
    if key == keys.up then
      currentCategory = currentCategory - 1
      if currentCategory < 1 then
        currentCategory = #categories
      end
      drawLauncher()
    elseif key == keys.down then
      currentCategory = currentCategory + 1
      if currentCategory > #categories then
        currentCategory = 1
      end
      drawLauncher()
    elseif key == keys.enter then
      openCategory()
    end
  end
end

local function main()
  createDirectories()
  drawLauncher()
  handleInput()
end

createDirectories()

parallel.waitForAny(main, function()
  while true do
    sleep(1)
  end
end)
