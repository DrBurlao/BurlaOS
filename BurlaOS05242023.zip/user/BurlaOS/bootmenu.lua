-- Configuration file path
local configFile = "/.settings"
local bootSettingsFile = "/bootsettings.txt"

-- Function to read the current configuration
local function readConfig()
    if fs.exists(configFile) then
        local file = fs.open(configFile, "r")
        local config = file.readAll()
        file.close()
        return config
    else
        return ""
    end
end

-- Function to write the configuration
local function writeConfig(config)
    local file = fs.open(configFile, "w")
    file.write(config)
    file.close()
end

-- Function to parse the configuration
local function parseConfig(config)
    local settings = {}
    for setting in config:gmatch("[^\n]+") do
        local option, value = setting:match("([^=]+)=(.+)")
        settings[option] = value == "true"
    end
    return settings
end

-- Function to get the current value of an option
local function getOptionValue(settings, option)
    return settings[option] or false
end

-- Function to set the value of an option
local function setOptionValue(settings, option, value)
    settings[option] = value
end

-- Function to show the current state of all options
local function showOptions(settings)
    term.clear()
    term.setCursorPos(1, 1)
    print("Current state of the options:")
    for option, value in pairs(settings) do
        print(option .. ":", value)
    end
    print("\nPress any key to continue...")
    os.pullEvent("key")
end

-- Function to create the configuration file and the backup
local function createFiles()
    if not fs.exists(configFile) then
        local defaultConfig = "shell.autocomplete=false\nlua.autocomplete=false\nedit.autocomplete=false"
        writeConfig(defaultConfig)
        print("Configuration file created.")
    end

    if not fs.exists(bootSettingsFile) then
        local config = readConfig()
        writeConfig(config)
        print("Configuration backup created.")
    end
end

-- Function to detect and show monitors on PC and connected monitors
local function detectAndShowMonitors()
    -- Find monitors
    local monitors = peripheral.find("monitor")
    local wiredModems = peripheral.find("wired_modem")

    -- Determine the monitor resolution
    local resolutionX, resolutionY
    local term = term.current()
    if term.isColor() then
        resolutionX, resolutionY = term.getSize()
    else
        resolutionX, resolutionY = term.getSize()
        resolutionX = resolutionX * 2
    end

    -- Show on the PC screen
    term.clear()
    term.setCursorPos(1, 1)
    print("Connected monitors:")
    for _, monitor in pairs(monitors) do
        monitor.setTextScale(1)
        monitor.clear()
        monitor.setCursorPos(1, 1)
        monitor.write("Hello from the PC!")
    end

    -- Show on monitors connected via wired modems
    if wiredModems then
        for _, modem in pairs(wiredModems) do
            local monitor = peripheral.call(modem, "getMonitor")
            if monitor then
                monitor.setTextScale(1)
                monitor.clear()
                monitor.setCursorPos(1, 1)
                monitor.write("Hello from the connected monitor!")
            end
        end
    end

    -- Wait for the user to press any key to continue
    print("\nPress any key to continue...")
    os.pullEvent("key")
    term.clear()
    term.setCursorPos(1, 1)
end

-- Function to show the main menu
local function showMainMenu()
    term.clear()
    term.setCursorPos(1, 1)
    print("Welcome to the Configuration Program!")
    print("---------------------------------------")
    print("1. View current state of options")
    print("2. Change option")
    print("3. Show monitors")
    print("---------------------------------------")
    print("To restart, press 'R'.")
    print("To continue, press 'C'.")
    print("---------------------------------------")
end

-- Function to show the options menu
local function showOptionsMenu(settings)
    term.clear()
    term.setCursorPos(1, 1)
    print("Select the option you want to change:")
    local i = 1
    for option, _ in pairs(settings) do
        print(i .. ". " .. option)
        i = i + 1
    end
    print("---------------------------------------")
end

-- Function to change an option
local function changeOption(settings, option, value)
    if settings[option] == nil then
        print("Invalid option.")
    else
        setOptionValue(settings, option, value)
        print("Option changed successfully.")
    end
end

-- Main function
local function main()
    createFiles()

    local config = readConfig()
    local settings = parseConfig(config)

    local continue = true
    while continue do
        showMainMenu()
        print("Enter the number of the option you want to select:")
        local choice = read()

        if choice:lower() == "r" then
            print("Restarting...")
            continue = false
            shell.run("restart")
        elseif choice:lower() == "c" then
            print("Continuing...")
            continue = false
            shell.run("/user/BurlaOS/Loggin.lua")
        else
            choice = tonumber(choice)
            if choice == 1 then
                showOptions(settings)
            elseif choice == 2 then
                showOptionsMenu(settings)
                print("Enter the number of the option you want to change:")
                local optionIndex = tonumber(read())
                if optionIndex and optionIndex >= 1 and optionIndex <= #settings then
                    local option = next(settings, optionIndex)
                    print("Enter 'true' to enable the option or 'false' to disable it:")
                    local value = read() == "true"
                    changeOption(settings, option, value)
                else
                    print("Invalid option.")
                end
            elseif choice == 3 then
                detectAndShowMonitors()
            else
                print("Invalid option.")
            end
        end

        -- Clear the screen
        term.clear()
        term.setCursorPos(1, 1)
    end

    -- Generate the new configuration string
    local newConfig = ""
    for option, value in pairs(settings) do
        newConfig = newConfig .. option .. "=" .. tostring(value) .. "\n"
    end

    writeConfig(newConfig)
    writeConfig(newConfig, bootSettingsFile)
    print("Configuration saved successfully.")
    print("\nPress any key to exit...")
    os.pullEvent("key")
end

-- Error handling
local function handleError(errorMessage)
    term.clear()
    term.setCursorPos(1, 1)
    print("An error occurred!")
    print("---------------------------------------")
    print("Error message:")
    print(errorMessage)
    print("---------------------------------------")
    print("Press any key to exit...")
    os.pullEvent("key")
end

-- Program execution
local success, error = pcall(main)
if not success then
    handleError(error)
end
