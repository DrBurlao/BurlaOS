local colors = {
  background = colors.black,
  text = colors.white,
  headerBackground = colors.blue,
  headerText = colors.white,
  fileListBackground = colors.black,
  fileListText = colors.yellow
}

-- Función para detectar si hay un monitor adjunto
local function tieneMonitor()
  local peripherals = peripheral.getNames()
  for _, name in ipairs(peripherals) do
    if peripheral.getType(name) == "monitor" then
      return true
    end
  end
  return false
end

-- Función para detectar y obtener el módem conectado mediante cable
local function obtenerModem()
  local peripherals = peripheral.getNames()
  for _, name in ipairs(peripherals) do
    if peripheral.getType(name) == "modem" and peripheral.call(name, "isWireless") == false then
      return peripheral.wrap(name)
    end
  end
  return nil
end

-- Función para obtener la resolución del monitor adjunto
local function obtenerResolucionMonitor()
  local peripherals = peripheral.getNames()
  for _, name in ipairs(peripherals) do
    if peripheral.getType(name) == "monitor" then
      local monitor = peripheral.wrap(name)
      return monitor.getSize()
    end
  end
end

-- Función para mostrar la misma imagen en la computadora y el monitor
local function mostrarImagen(imagen, resolucion)
  term.clear()
  term.setCursorPos(1, 1)
  print("Mostrando imagen en la computadora y el monitor...")

  if tieneMonitor() then
    local monitorResX, monitorResY = obtenerResolucionMonitor()
    local monitor = peripheral.wrap(peripheral.getNames()[1])
    monitor.setTextScale(1)
    monitor.clear()
    monitor.setCursorPos(1, 1)
    monitor.blit(imagen, imagen, imagen)
    monitor.setCursorPos(1, 1)
    monitor.setTextScale(1)
  end

  local modem = obtenerModem()
  if modem then
    modem.transmit(1337, 1337, imagen)
  end

  term.clear()
  term.setCursorPos(1, 1)
  print("Imagen mostrada en la computadora y el monitor.")
end

-- Función para obtener el listado de archivos en una carpeta
local function obtenerListadoArchivos(carpeta)
  local archivos = fs.list(carpeta)
  table.sort(archivos) -- Ordenar alfabéticamente
  return archivos
end

-- Función para crear un archivo vacío si no existe
local function crearArchivo(nombreArchivo)
  if not fs.exists(nombreArchivo) then
    local file = fs.open(nombreArchivo, "w")
    file.close()
  end
end

-- Ruta de la carpeta que contiene los archivos
local carpetaArchivos = "user/BurlaOS/userapps/" -- Ajusta la ruta a tu carpeta deseada

-- Verificar si la carpeta existe
if not fs.exists(carpetaArchivos) or not fs.isDir(carpetaArchivos) then
  print("Error: La carpeta de programas no existe.")
  return
end

-- Obtener el listado de archivos en la carpeta
local archivos = obtenerListadoArchivos(carpetaArchivos)

-- Configurar el modo gráfico si hay un monitor adjunto
if tieneMonitor() then
  term.redirect(peripheral.wrap(peripheral.getNames()[1]))
  term.clear()
end

-- Configurar los colores de la consola
term.setBackgroundColor(colors.background)
term.setTextColor(colors.text)
term.clear()
term.setCursorPos(1, 1)

-- Mostrar el encabezado
term.setBackgroundColor(colors.headerBackground)
term.setTextColor(colors.headerText)
term.clearLine()
print(" Files found in " .. carpetaArchivos .. " ")
print(string.rep("-", term.getSize()))

-- Mostrar el listado de archivos
term.setBackgroundColor(colors.fileListBackground)
term.setTextColor(colors.fileListText)
if #archivos == 0 then
  print("No se encontraron archivos.")
else
  for i, archivo in ipairs(archivos) do
    print(i .. ". " .. archivo)
  end

  -- Obtener la selección del usuario
  print()
  term.setTextColor(colors.text)
  write("Select a file (1-" .. #archivos .. "): ")
  local seleccion = tonumber(read())

  -- Validar la selección del usuario
  if seleccion and seleccion >= 1 and seleccion <= #archivos then
    -- Obtener el archivo seleccionado
    local archivoSeleccionado = archivos[seleccion]

    -- Cargar el archivo en segundo plano utilizando bg
    term.clear()
    term.setCursorPos(1, 1)
    shell.run("bg", fs.combine(carpetaArchivos, archivoSeleccionado))

    -- Cerrar el programa principal
    term.setBackgroundColor(colors.background)
    term.setTextColor(colors.text)
    term.clear()
    term.setCursorPos(1, 1)
    print("The file " .. archivoSeleccionado .. " has been opened in the background.")
  else
    -- Mostrar mensaje de selección inválida
    term.setBackgroundColor(colors.background)
    term.setTextColor(colors.text)
    term.clear()
    term.setCursorPos(1, 1)
    print("Invalid selection. The program has been closed.")
  end
end
