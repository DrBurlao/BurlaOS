-- Login and Account Creation Program in Computercraft

-- Path of the login information file
local filePath = "/user/BurlaOS/Loggininfo.txt"

-- Monitor resolution configuration variables
local monitorWidth, monitorHeight

-- Find and select the first attached monitor
local monitor = peripheral.find("monitor")

-- Check if a monitor is found
if monitor then
  -- Get the monitor resolution
  monitorWidth, monitorHeight = monitor.getSize()

  -- Configure the monitor to display the output
  monitor.setTextScale(1)
  monitor.clear()
end

-- Colors
local colors = {
  white = colors.white,
  green = colors.lime,
  red = colors.red,
  yellow = colors.yellow
}

-- Function to center text on the monitor
local function centerText(y, text, color)
  if monitor then
    local textLength = string.len(text)
    local x = math.floor((monitorWidth - textLength) / 2) + 1
    monitor.setCursorPos(x, y)
    monitor.setTextColor(color)
    monitor.write(text)
  end
end

-- Function to display output on the terminal and the attached monitor
local function showOutput(y, text, color)
  -- Display the output on the terminal
  term.setCursorPos(1, y)
  term.setTextColor(color)
  term.write(text)

  -- Check if a monitor is found
  if monitor then
    -- Display the output on the monitor
    centerText(y, text, color)
  end
end

-- Function to get user input
local function getInput(y, message, color)
  -- Display the message on the terminal and the attached monitor
  showOutput(y, message, color)

  -- Get the user input
  return read()
end

-- Function to encrypt a string using XOR encryption
local function encrypt(text, key)
  local encryptedText = ""
  for i = 1, #text do
    local byteText = string.byte(text, i)
    local byteKey = string.byte(key, (i - 1) % #key + 1)
    local encryptedByte = bit.bxor(byteText, byteKey)
    encryptedText = encryptedText .. string.char(encryptedByte)
  end
  return encryptedText
end

-- Function to decrypt a string using XOR encryption
local function decrypt(encryptedText, key)
  return encrypt(encryptedText, key) -- XOR encryption is symmetric, encrypting and decrypting are the same
end

-- Function to verify user credentials
local function verifyCredentials(username, password)
  -- Check if the file exists
  if fs.exists(filePath) then
    -- Read the stored credentials from the file
    local file = fs.open(filePath, "r")
    local encryptedUsername = file.readLine()
    local encryptedPassword = file.readLine()
    file.close()

    -- Decrypt the credentials
    local decryptedUsername = decrypt(encryptedUsername, "secret_key")
    local decryptedPassword = decrypt(encryptedPassword, "secret_key")

    return username == decryptedUsername and password == decryptedPassword
  else
    return false
  end
end

-- Function to create a new user account
local function createAccount(username, password)
  -- Encrypt the credentials
  local encryptedUsername = encrypt(username, "secret_key")
  local encryptedPassword = encrypt(password, "secret_key")

  -- Open the file in write mode, if it doesn't exist, create it
  local file = fs.open(filePath, "w")
  file.writeLine(encryptedUsername)
  file.writeLine(encryptedPassword)
  file.close()

  showOutput(6, "Account created successfully.", colors.green)
end

-- Function to detect attached monitors and wired modems
local function detectMonitorsAndModems()
  -- Find attached monitors
  local monitors = peripheral.find("monitor", nil, function(_, name, peripheralLocation)
    return peripheralLocation == "top" or peripheralLocation == "bottom" or peripheralLocation == "front" or peripheralLocation == "back" or peripheralLocation == "right" or peripheralLocation == "left"
  end)

  -- Find wired modems
  local modems = peripheral.find("wired_modem", nil, function(_, name, peripheralLocation)
    return peripheralLocation == "top" or peripheralLocation == "bottom" or peripheralLocation == "front" or peripheralLocation == "back" or peripheralLocation == "right" or peripheralLocation == "left"
  end)

  -- Configure the monitors to display the program
  for _, monitor in ipairs(monitors) do
    monitor.setTextScale(1)
    monitor.clear()
  end

  -- Check if wired modems are found
  if modems then
    -- Configure the wired modems to send messages to all monitors
    for _, modem in ipairs(modems) do
      modem.open(65535)
    end
  end

  return monitors
end

-- Function to clear the screen on all monitors
local function clearMonitors(monitors)
  for _, monitor in ipairs(monitors) do
    monitor.clear()
  end
end

-- Example ASCII art
local asciiArt = [[
  ____           _       _     ______     __
 / ___|   __ _  (_)   __| |   / ___\ \   / /
| |  _   / _` | | |  / _` |  | |    \ \ / / 
| |_| | | (_| | | | | (_| |  | |___  \ V /  
 \____|  \__,_| |_|  \__,_|   \____|  \_/   
]]

-- Function for the login process
local function loginProcess()
  -- Detect attached monitors and wired modems
  local monitors = detectMonitorsAndModems()

  -- Clear all monitors
  clearMonitors(monitors)

  -- Display ASCII art and login message on all monitors
  for _, monitor in ipairs(monitors) do
    monitor.setCursorPos(1, 1)
    monitor.setTextColor(colors.white)
    monitor.write(asciiArt)
    centerText(12, "=== Login ===", colors.yellow)
  end

  local username = getInput(14, "Username", colors.white)
  local password = getInput(16, "Password", colors.white)

  if verifyCredentials(username, password) then
    -- Clear all monitors
    clearMonitors(monitors)

    -- Display successful login message on all monitors
    for _, monitor in ipairs(monitors) do
      centerText(12, "Login successful", colors.green)
    end

    -- Run the BurlaOS.lua program
    shell.run("/user/BurlaOS/BurlaOS.lua")

    -- Close the login program
    return
  else
    -- Clear all monitors
    clearMonitors(monitors)

    -- Display invalid credentials message on all monitors
    for _, monitor in ipairs(monitors) do
      centerText(12, "Invalid credentials", colors.red)
    end

    local option = getInput(14, "Create a new account? (y/n)", colors.white)

    if option == "y" or option == "Y" then
      createAccount(username, password)
    end
  end
end

-- Call the login process function
loginProcess()

-- Display the function of the Control key
showOutput(16, "Press Left Control to Shutdown", colors.yellow)

-- Wait for the "left control" key to be pressed to shutdown
while true do
  local event, key = os.pullEvent("key")
  if event == "key" and key == keys.leftCtrl then
    os.shutdown()
    break
  end
end
