local monitor = nil
local term = nil

-- Search for an attached monitor
for _, p in ipairs(peripheral.getNames()) do
  if peripheral.getType(p) == "monitor" then
    monitor = peripheral.wrap(p)
    if monitor.isColor() then
      break
    else
      monitor = nil
    end
  end
end

-- Search for a connected modem
local modem = peripheral.find("modem")

if modem and not monitor then
  -- Search for a monitor through the modem
  modem.transmit(1, 1, "monitor_detect")
  local timer = os.startTimer(5)
  while true do
    local event, side, channel, reply, message = os.pullEvent()
    if event == "modem_message" and channel == 1 and message == "monitor_attached" then
      monitor = peripheral.wrap(side)
      if monitor.isColor() then
        break
      else
        monitor = nil
      end
    elseif event == "timer" and side == timer then
      break
    end
  end
end

-- If a monitor is found, use it as the terminal
if monitor then
  term = monitor
else
  term = peripheral.find("terminal")
end

if not term then
  error("No monitor or wired modem detected.")
end

local categories = {
  {name = "Programs", path = "/user/BurlaOS/types/Programs.lua"},
  {name = "File Explorer", path = "/user/BurlaOS/types/FileExplorer.lua"},
  {name = "Installed user apps", path = "/user/BurlaOS/types/UserApps.lua"},
  {name = "Control panel", path = "/user/BurlaOS/types/ControlPanel.lua"},
  {name = "Multimedia", path = "/user/BurlaOS/types/Multimedia.lua"},
  {name = "Shutdown", path = "/user/BurlaOS/types/Shutdown.lua"}
}

local currentCategory = 1

local function clearScreen()
  term.setTextColor(colors.white)
  term.setBackgroundColor(colors.black)
  term.clear()
  term.setCursorPos(1, 1)
end

local function drawLauncher()
  clearScreen()

  local width, height = term.getSize()

  term.setTextColor(colors.yellow)
  term.setCursorPos((width - 13) / 2, 1)
  term.write("=== Launcher ===")

  local startY = math.floor((height - #categories) / 2) - 1

  for i, category in ipairs(categories) do
    term.setTextColor(colors.white)
    term.setCursorPos((width - #category.name) / 2, startY + i * 2)

    if i == currentCategory then
      term.setTextColor(colors.green)
      term.write("> ")
    else
      term.write("  ")
    end

    term.write(category.name)
  end
end

local function createDirectory(directory)
  if not fs.exists(directory) then
    fs.makeDir(directory)
  end
end

local function createDirectories()
  for _, category in ipairs(categories) do
    createDirectory(category.path)
  end
end

local function scanPrograms(directory)
  local programs = {}
  local files = fs.list(directory)

  for _, file in ipairs(files) do
    local fullPath = fs.combine(directory, file)
    if not fs.isDir(fullPath) and file:sub(-4) == ".lua" then
      table.insert(programs, file:sub(1, -5))
    end
  end

  return programs
end

local function openCategory(category)
  if category.name == "Programs" then
    local success, err = pcall(shell.run, "bg " .. category.path)
    if not success then
      clearScreen()
      term.setTextColor(colors.red)
      term.write("Error running " .. category.name .. ": " .. err)
      sleep(5)
    end
  else
    -- Handle other categories
  end
end

local function handleInput()
  while true do
    local event, key = os.pullEvent("key")

    if key == keys.up then
      currentCategory = currentCategory - 1
      if currentCategory < 1 then
        currentCategory = #categories
      end
      drawLauncher()
    elseif key == keys.down then
      currentCategory = currentCategory + 1
      if currentCategory > #categories then
        currentCategory = 1
      end
      drawLauncher()
    elseif key == keys.enter then
      local category = categories[currentCategory]
      local success, err = pcall(function()
        openCategory(category)
      end)
      if not success then
        clearScreen()
        term.setTextColor(colors.red)
        term.write("Error: " .. err)
        sleep(5)
        drawLauncher()
      end
    end
  end
end

local function main()
  clearScreen()

  local success, err = pcall(function()
    createDirectories()
    drawLauncher()
    handleInput()
  end)

  if not success then
    clearScreen()
    term.setTextColor(colors.red)
    term.write("Error: " .. err)
    sleep(5)
  end
end

-- Run Hypervisor in background
local function runHypervisor()
  local success, err = pcall(shell.run, "bg /user/BurlaOS/Hypervisor")

  if not success then
    clearScreen()
    term.setTextColor(colors.red)
    term.write("Error running Hypervisor: " .. err)
    sleep(5)
  end
end

-- Run Taskmanager in background
local function runTaskmanager()
  local success, err = pcall(shell.run, "bg /user/BurlaOS/Taskmanager")

  if not success then
    clearScreen()
    term.setTextColor(colors.red)
    term.write("Error running Taskmanager: " .. err)
    sleep(5)
  end
end

-- Create necessary directories
local success, err = pcall(createDirectories)

if not success then
  clearScreen()
  term.setTextColor(colors.red)
  term.write("Error creating directories: " .. err)
  sleep(5)
end

-- Run Hypervisor and Taskmanager in background
parallel.waitForAll(runHypervisor, runTaskmanager)

main()
local monitor = nil
local term = nil

-- Search for an attached monitor
for _, p in ipairs(peripheral.getNames()) do
  if peripheral.getType(p) == "monitor" then
    monitor = peripheral.wrap(p)
    if monitor.isColor() then
      break
    else
      monitor = nil
    end
  end
end

-- Search for a connected modem
local modem = peripheral.find("modem")

if modem and not monitor then
  -- Search for a monitor through the modem
  modem.transmit(1, 1, "monitor_detect")
  local timer = os.startTimer(5)
  while true do
    local event, side, channel, reply, message = os.pullEvent()
    if event == "modem_message" and channel == 1 and message == "monitor_attached" then
      monitor = peripheral.wrap(side)
      if monitor.isColor() then
        break
      else
        monitor = nil
      end
    elseif event == "timer" and side == timer then
      break
    end
  end
end

-- If a monitor is found, use it as the terminal
if monitor then
  term = monitor
else
  term = peripheral.find("terminal")
end

if not term then
  error("No monitor or wired modem detected.")
end

local categories = {
  {name = "Programs", path = "/user/BurlaOS/types/programs.lua"},
  {name = "File Explorer", path = "/user/BurlaOS/types/FileExplorer.lua"},
  {name = "Installed user apps", path = "/user/BurlaOS/types/UserApps.lua"},
  {name = "Control panel", path = "/user/BurlaOS/types/ControlPanel.lua"},
  {name = "Multimedia", path = "/user/BurlaOS/types/Multimedia.lua"},
  {name = "Shutdown", path = "/user/BurlaOS/types/Shutdown.lua"}
}

local currentCategory = 1

local function clearScreen()
  term.setTextColor(colors.white)
  term.setBackgroundColor(colors.black)
  term.clear()
  term.setCursorPos(1, 1)
end

local function drawLauncher()
  clearScreen()

  local width, height = term.getSize()

  term.setTextColor(colors.yellow)
  term.setCursorPos((width - 13) / 2, 1)
  term.write("=== Launcher ===")

  local startY = math.floor((height - #categories) / 2) - 1

  for i, category in ipairs(categories) do
    term.setTextColor(colors.white)
    term.setCursorPos((width - #category.name) / 2, startY + i * 2)

    if i == currentCategory then
      term.setTextColor(colors.green)
      term.write("> ")
    else
      term.write("  ")
    end

    term.write(category.name)
  end
end

local function createDirectory(directory)
  if not fs.exists(directory) then
    fs.makeDir(directory)
  end
end

local function createDirectories()
  for _, category in ipairs(categories) do
    createDirectory(category.path)
  end
end

local function scanPrograms(directory)
  local programs = {}
  local files = fs.list(directory)

  for _, file in ipairs(files) do
    local fullPath = fs.combine(directory, file)
    if not fs.isDir(fullPath) and file:sub(-4) == ".lua" then
      table.insert(programs, file:sub(1, -5))
    end
  end

  return programs
end

local function runProgram(path)
  local success, err = pcall(shell.run, "bg " .. path)
  if not success then
    clearScreen()
    term.setTextColor(colors.red)
    term.write("Error running " .. path .. ": " .. err)
    sleep(5)
  end
end

local function openCategory(category)
  if category.name == "Programs" then
    local programs = scanPrograms(category.path)
    if #programs > 0 then
      for _, program in ipairs(programs) do
        runProgram(fs.combine(category.path, program .. ".lua"))
      end
    else
      clearScreen()
      term.setTextColor(colors.red)
      term.write("No programs found in " .. category.name)
      sleep(5)
    end
  else
    runProgram(category.path)
  end
end

local function handleInput()
  while true do
    local event, key = os.pullEvent("key")

    if key == keys.up then
      currentCategory = currentCategory - 1
      if currentCategory < 1 then
        currentCategory = #categories
      end
      drawLauncher()
    elseif key == keys.down then
      currentCategory = currentCategory + 1
      if currentCategory > #categories then
        currentCategory = 1
      end
      drawLauncher()
    elseif key == keys.enter then
      local category = categories[currentCategory]
      local success, err = pcall(function()
        openCategory(category)
      end)
      if not success then
        clearScreen()
        term.setTextColor(colors.red)
        term.write("Error: " .. err)
        sleep(5)
        drawLauncher()
      end
    end
  end
end

local function main()
  clearScreen()

  local success, err = pcall(function()
    createDirectories()
    drawLauncher()
    handleInput()
  end)

  if not success then
    clearScreen()
    term.setTextColor(colors.red)
    term.write("Error: " .. err)
    sleep(5)
  end
end

-- Create necessary directories
createDirectories()

-- Run Hypervisor and Taskmanager in background
parallel.waitForAny(
  function()
    local success, err = pcall(shell.run, "bg /user/BurlaOS/Hypervisor")
    if not success then
      clearScreen()
      term.setTextColor(colors.red)
      term.write("Error running Hypervisor: " .. err)
      sleep(5)
    end
  end,
  function()
    local success, err = pcall(shell.run, "bg /user/BurlaOS/Taskmanager")
    if not success then
      clearScreen()
      term.setTextColor(colors.red)
      term.write("Error running Taskmanager: " .. err)
      sleep(5)
    end
  end
)

main()
