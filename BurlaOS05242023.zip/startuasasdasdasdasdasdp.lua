-- RAM storage folder
local ramFolder = "/RAM/"

-- Create RAM storage folder if it doesn't exist
if not fs.exists(ramFolder) then
  fs.makeDir(ramFolder)
end

-- Function to launch a new process in a tab
local function launchNewTab(programPath, arguments)
  local newTabID = multishell.launch({}, programPath, arguments)
  if not newTabID then
    error("Error launching program in a new tab.")
  end
  multishell.setFocus(newTabID)
  return newTabID
end

-- Function to set the title of a tab
local function setTabTitle(tabID, title)
  local success = multishell.setTitle(tabID, title)
  if not success then
    error("Error setting tab title.")
  end
end

-- Function to get the title of a tab
local function getTabTitle(tabID)
  local title = multishell.getTitle(tabID)
  if not title then
    error("Error getting tab title.")
  end
  return title
end

-- Function to switch focus to a specific tab
local function switchTab(tabID)
  local success = multishell.setFocus(tabID)
  if not success then
    error("Error switching focus to tab.")
  end
end

-- Function to save data to a file in the RAM storage folder
local function saveDataToFile(filename, data)
  local file = fs.open(ramFolder .. filename, "w")
  if not file then
    error("Error opening file to write data.")
  end
  file.write(data)
  file.close()
end

-- Function to delete a file from the RAM storage folder
local function deleteFile(filename)
  local filepath = ramFolder .. filename
  if fs.exists(filepath) then
    local success = fs.delete(filepath)
    if not success then
      error("Error deleting file.")
    end
  end
end

-- Function to run the main process
local function runMainProcess()
  -- Get the current tab ID
  local tabID = multishell.getCurrent()

  -- Get the title of the current tab
  local tabTitle = getTabTitle(tabID)

  -- Get the start time from the file (if it exists)
  local startTime = nil
  local filename = tabID .. ".txt"
  local filepath = ramFolder .. filename
  if fs.exists(filepath) then
    local file = fs.open(filepath, "r")
    if file then
      startTime = tonumber(file.readLine())
      file.close()
    end
  end

  -- Calculate the runtime
  local runtime = os.time() - (startTime or os.time())

  -- Save the start time to the file
  local file = fs.open(filepath, "w")
  if file then
    file.write(runtime .. "\n")
    file.close()
  end

  -- Save the data to a file in the RAM storage folder
  saveDataToFile(filename, "Tab: " .. tabTitle .. "\nRuntime: " .. runtime .. " seconds")
end

-- Function to run the subprocess
local function runSubprocess()
  -- Get the current tab ID
  local tabID = multishell.getCurrent()

  -- Get the title of the current tab
  local tabTitle = getTabTitle(tabID)

  -- Save the data to a file in the RAM storage folder
  saveDataToFile(tabID .. ".txt", "Running subprocess in the tab: " .. tabTitle)
end

-- Function to handle system events
local function handleEvents()
  while true do
    local event = {os.pullEventRaw()}

    if event[1] == "key" then
      local keyCode = event[2]

      -- Switch focus to the next tab when the "Tab" key is pressed
      if keyCode == keys.tab then
        local tabCount = multishell.getCount()
        local currentTabID = multishell.getCurrent()
        local nextTabID = (currentTabID % tabCount) + 1
        switchTab(nextTabID)
      end
    elseif event[1] == "shutdown" then
      -- Delete the files stored in the RAM storage folder
      local files = fs.list(ramFolder)
      for _, file in ipairs(files) do
        deleteFile(file)
      end
      break
    end
  end
end

-- Main function
local function main()
  local success, error = pcall(function()
    -- Run the main process
    runMainProcess()

    -- Run the subprocess
    runSubprocess()

    -- Handle system events
    handleEvents()
  end)

  if not success then
    print("Error: " .. error)
    -- Add additional logic here to handle the error
  end
end

-- Execute the main function
main()
